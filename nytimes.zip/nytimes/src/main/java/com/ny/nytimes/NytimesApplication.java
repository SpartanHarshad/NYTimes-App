package com.ny.nytimes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NytimesApplication {

	public static void main(String[] args) {
		SpringApplication.run(NytimesApplication.class, args);
	}

}
