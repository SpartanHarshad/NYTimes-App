package com.ny.nytimes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NytimesApplicationTests {

	@Test
	void contextLoads() {
	}

}
